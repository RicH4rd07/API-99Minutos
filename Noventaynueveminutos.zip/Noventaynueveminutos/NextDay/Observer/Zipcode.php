<?php
 
namespace Noventaynueveminutos\NextDay\Observer;
 
use Magento\Framework\Event\ObserverInterface;
 
class Zipcode implements ObserverInterface
{
 
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        try 
            {
              $order = $observer->getEvent()->getOrder(); 
            }

        catch(\Exception $e)
            {
              $this->logger->info($e->getMessage());
            }
            
        $shippingMethod = $order->getShippingMethod();

        if($shippingMethod ==='Noventaynueveminutos_NextDay_Noventaynueveminutos_NextDay')
            {
              $shippingMethod1 = 'Noventaynueveminutos_NextDay_Noventaynueveminutos_NextDay';
              
            }
        elseif ($shippingMethod ==='Noventaynueveminutos_SameDay_Noventaynueveminutos_SameDay')
            {
              $shippingMethod1 = 'Noventaynueveminutos_SameDay_Noventaynueveminutos_SameDay';
              
            }
        elseif ($shippingMethod ==='Noventaynueveminutos_CO2free_Noventaynueveminutos_CO2free')
            {
              $shippingMethod1 = 'Noventaynueveminutos_CO2free_Noventaynueveminutos_CO2free';
              
            }
        elseif ($shippingMethod ==='Noventaynueveminutos_Noventaynueveminutos_Noventaynueveminutos_Noventaynueveminutos')
            {
              $shippingMethod1 = 'Noventaynueveminutos_Noventaynueveminutos_Noventaynueveminutos_Noventaynueveminutos';
              
            }
        else{
              $shippingMethod1 = '...';
            }
        
        if($shippingMethod === $shippingMethod1)
        {

            $zipCode = $order->getShippingAddress()->getData('postcode');

            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, "https://deploy-dot-precise-line-76299minutos.appspot.com/api/v1/cat/coveage");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($ch, CURLOPT_HEADER, FALSE);
            curl_setopt($ch, CURLOPT_POST, TRUE);
            curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"coverage\": \"{$zipCode}\"}");
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "Content-Type: application/json", "Authorization:Bearer bdb34292bb1666be2235c9a903450b7837cfb156"
            ));

            $response = curl_exec($ch);
            curl_close($ch);

            $jsonResponse = json_decode($response, true);

            try 
            {
                $coverage = $jsonResponse['coverage']['message'];
            }

            catch(\Exception $e)
            {
                $coverage = '';
            }

            if($coverage === false)
            {
                $message = "Lo sentimos, 99 minutos no tiene cobertura en tu zona";
                throw new \Magento\Framework\Exception\LocalizedException(__($message));
                return;
            }
            else
            {
                $coverage;
            }

        }//CIERRE IF SHIPPING METHOD

    } //CIERRE OBSERVER
 
} //CIERRE CLASE